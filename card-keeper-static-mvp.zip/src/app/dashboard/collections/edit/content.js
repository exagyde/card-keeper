"use client";

import "./style.css";

import { useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { doc, getDoc, updateDoc, deleteDoc, collection, getDocs, addDoc, serverTimestamp } from "firebase/firestore";
import { auth, firestore } from "@/firebase/config";

export default function EditCollectionContent() {
    const searchParams = useSearchParams();
    const id = searchParams.get("id");

    const router = useRouter();
    const [user, setUser] = useState(null);
    const [collectionName, setCollectionName] = useState("");
    const [collectionDescription, setCollectionDescription] = useState("");
    const fileInputRef = useRef(null);
    const [cards, setCards] = useState([]);
    const [newCardFile, setNewCardFile] = useState(null);
    const [newCardName, setNewCardName] = useState("");

    useEffect(() => {
        if (!id) {
            router.replace("/dashboard");
            return;
        }
        
        const unsubscribe = auth.onAuthStateChanged(async (user) => {
            if (user) {
                setUser(user);
                await loadCollection(user.uid);
            } else {
                router.replace("/login");
            }
        });

        return () => unsubscribe();
    }, [router]);

    const loadCollection = async (uid) => {
        const collectionRef = doc(firestore, "collections", id);
        const collectionSnap = await getDoc(collectionRef);
        if (!collectionSnap.exists() || collectionSnap.data().userId !== uid) {
            router.replace("/dashboard");
            return;
        }
        const collectionData = { id: collectionSnap.id, ...collectionSnap.data() };
        setCollectionName(collectionData.name);
        setCollectionDescription(collectionData.description);

        const cardsRef = collection(firestore, "collections", id, "cards");
        const cardsSnap = await getDocs(cardsRef);
        const cardsData = cardsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setCards(cardsData);
    }

    const handleUpdate = async (e) => {
        e.preventDefault();
        await updateDoc(doc(firestore, "collections", id), {
            name: collectionName,
            description: collectionDescription,
            updatedAt: serverTimestamp()
        });
        router.replace("/dashboard");
    }

    const handleDelete = async () => {
        const cardsRef = collection(firestore, "collections", id, "cards");
        const cardsSnapshot = await getDocs(cardsRef);

        const deletePromises = cardsSnapshot.docs.map((cardDoc) =>
            deleteDoc(doc(firestore, "collections", id, "cards", cardDoc.id))
        );
        await Promise.all(deletePromises);
        await deleteDoc(doc(firestore, "collections", id));
        router.replace("/dashboard");
    }

    const handleAddCard = async (e) => {
        e.preventDefault();

        if(newCardFile && newCardFile.size > 1024 * 1024) {
            alert("File size exceeds 1MB limit.");
            return;
        }

        await updateDoc(doc(firestore, "collections", id), { 
            updatedAt: serverTimestamp() 
        });

        if(newCardFile) {
            const reader = new FileReader();
            reader.onloadend = async () => {
                const base64Image = reader.result;
                await addDoc(collection(firestore, "collections", id, "cards"), {
                    name: newCardName,
                    image: base64Image,
                    createdAt: serverTimestamp()
                });
                setNewCardName("");
                setNewCardFile(null);
                if(fileInputRef.current) fileInputRef.current.value = null;
                loadCollection(user.uid);
            };
            reader.readAsDataURL(newCardFile);
            return;
        }

        await addDoc(collection(firestore, "collections", id, "cards"), {
            name: newCardName,
            createdAt: serverTimestamp()
        });

        setNewCardName("");
        loadCollection(user.uid);
    }

    const handleDeleteCard = async (cardId) => {
        await deleteDoc(doc(firestore, "collections", id, "cards", cardId));
        await updateDoc(doc(firestore, "collections", id), { 
            updatedAt: serverTimestamp() 
        });
        loadCollection(user.uid);
    }
    
    return (
        <div id="edit-collection">
            <div>
                <a href="/dashboard">GO TO DASHBOARD</a>
                <h4>EDIT COLLECTION</h4>
                <form onSubmit={handleUpdate}>
                    <div>
                        <label htmlFor="name">Name</label>
                        <input 
                            type="text" 
                            id="name" 
                            name="name" 
                            value={collectionName}
                            onChange={(e) => setCollectionName(e.target.value)}
                            required 
                        />
                    </div>
                    <div>
                        <label htmlFor="description">Description</label>
                        <textarea 
                            id="description" 
                            name="description" 
                            value={collectionDescription}
                            onChange={(e) => setCollectionDescription(e.target.value)}
                            rows={2}
                            required
                        />
                    </div>
                    <div>
                        <button type="submit" className="secondary">Update</button>
                        <button type="button" className="red" onClick={handleDelete}>Delete</button>
                    </div>
                </form>
            </div>
            <div>
                <h4>CARDS IN THIS COLLECTION</h4>
                <form onSubmit={handleAddCard}>
                    <input 
                        type="file"
                        accept="image/png,image/jpeg"
                        ref={fileInputRef}
                        onClick={() => setNewCardFile(null)}
                        onChange={(e) => setNewCardFile(e.target.files[0])}
                    />
                    <input 
                        type="text" 
                        placeholder="New Card Name" 
                        value={newCardName}
                        onChange={(e) => setNewCardName(e.target.value)}
                        required
                    />
                    <button type="submit">Add</button>
                </form>
                <div>
                    {cards.length === 0 ? (
                        <p>No cards in this collection.</p>
                    ) : (
                        <table>
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>Card Name</th>
                                    <th>Created At</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                {cards.map(card => (
                                    <tr key={card.id}>
                                        <td>
                                            {card.image ? (
                                                <img src={card.image} alt={card.name} style={{ width: "50px" }} />
                                            ) : (
                                                <span>No Image</span>
                                            )}
                                        </td>
                                        <td>{card.name}</td>
                                        <td>{card.createdAt?.toDate().toLocaleDateString("fr")}</td>
                                        <td>
                                            <a href="#" className="red" onClick={() => handleDeleteCard(card.id)}>Delete</a>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
            </div>
        </div>
    );
}
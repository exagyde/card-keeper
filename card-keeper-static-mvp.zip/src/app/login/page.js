"use client";

import "./style.css";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { signInWithEmailAndPassword, signInWithPopup, GoogleAuthProvider } from "firebase/auth";
import { auth } from "@/firebase/config";

const provider = new GoogleAuthProvider();

export default function LoginPage() {
    const router = useRouter();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const [checkAuth, setCheckAuth] = useState(true);

    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged((user) => {
            if (user) { router.replace("/dashboard"); } 
            else { setCheckAuth(false); }
        });

        return () => unsubscribe();
    }, [router]);
    if(checkAuth) return <p>Loading...</p>;

    const handleLogin = async (e) => {
        e.preventDefault();
        setError("");

        try {
            await signInWithEmailAndPassword(auth, email, password);
            router.replace("/dashboard");
        } catch (err) {
            setError(err.message);
        }
    };

    const handleGoogleLogin = async () => {
        setError("");

        try {
            await signInWithPopup(auth, provider);
            router.replace("/dashboard");
        } catch (err) {
            setError(err.message);
        }
    };

    return (
        <div id="signin">
            <form onSubmit={handleLogin}>
                <h3>Sign In</h3>
                <div>
                    <label>Email</label>
                    <input
                        type="email"
                        placeholder="Enter your email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label>Password</label>
                    <input
                        type="password"
                        placeholder="Enter your password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                    <a href="/forgot-password">Forgot password ?</a>
                </div>
                <button type="submit">Login</button>
                <div>
                    <hr />
                    <p>Or</p>
                    <hr />
                </div>
                <button type="button" className="google" onClick={handleGoogleLogin}>Sign in with Google</button>
                {error && <p style={{ color: "red" }}>{error}</p>}
            </form>

            <p>Don&apos;t have an account?</p>
            <a href="/signup">Sign Up</a>
        </div>
    );
}
"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { auth } from "@/firebase/config";

export default function RequireAuth({ children, redirectTo = "/login" }) {
    const router = useRouter();
    const [checkAuth, setCheckAuth] = useState(true);
    const [user, setUser] = useState(null);

    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged((currentUser) => {
            if (currentUser) { setUser(currentUser); } 
            else { router.replace(redirectTo); }
            setCheckAuth(false);
        });

        return () => unsubscribe();
    }, [router, redirectTo]);

    if(checkAuth) return <p>Loading...</p>;
    if (!user) return null;
    return <>{children}</>;
}
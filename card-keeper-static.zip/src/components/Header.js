"use client";

import "./Header.css";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { auth } from "@/firebase/config";

export default function Header() {
    const router = useRouter();
    const [user, setUser] = useState(null);

    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged((currentUser) => {
            setUser(currentUser);
        });

        return () => unsubscribe();
    }, []);

    const handleLogout = async () => {
        await auth.signOut();
        router.replace("/login");
    };

    return (
        <header>
            <img src="/svg/icon.svg" alt="Logo" onClick={() => router.replace("/")} />
            <h1>card-keeper</h1>
            <div>
                {user && (
                    <>
                        <img src="/svg/user.svg" alt="User Icon" />
                        <div id="user-info">
                            <p>{user.email}</p>
                            <button className="secondary red" onClick={handleLogout}>Logout</button>
                        </div>
                    </>
                )}
            </div>
        </header>
    );
}
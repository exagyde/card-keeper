"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { auth, firestore } from "@/firebase/config";
import { collection, getDocs, query, where, deleteDoc, doc } from "firebase/firestore";
import RequireAuth from "@/components/RequireAuth";

export default function DashboardPage() {
    const router = useRouter();
    const [collections, setCollections] = useState([]);
    const [userEmail, setUserEmail] = useState("");

    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged(async (user) => {
            if (user) {
                setUserEmail(user.email);
                const userCollectionsQuery = query(
                    collection(firestore, "collections"),
                    where("userId", "==", user.uid)
                );
                const querySnapshot = await getDocs(userCollectionsQuery);
                const userCollections = querySnapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data()
                }));
                setCollections(userCollections);
            } else {
                router.push("/login");
            }
        });

        return () => unsubscribe();
    }, [router]);

    const handleLogout = async () => {
        await auth.signOut();
        router.push("/login");
    };

    const handleDeleteCollection = async (id) => {
        await deleteDoc(doc(firestore, "collections", id));
        setCollections(prevCollections => prevCollections.filter(c => c.id !== id));
    }

    return (
        <RequireAuth>
            <button type="button" onClick={handleLogout}>Logout</button>
            <h1>Welcome to your Dashboard, {userEmail}</h1>
            <a href="/dashboard/collections/new">+ New collection</a>
            {collections.length === 0 ? (
                <p>Collections empty.</p>
            ) : (
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Created at</th>
                            <th>Updated at</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {collections.map((collection) => (
                            <tr key={collection.id}>
                                <td>{collection.name}</td>
                                <td>{collection.createdAt?.toDate().toDateString()}</td>
                                <td>{collection.updatedAt?.toDate().toDateString()}</td>
                                <td>
                                    <a href={`/dashboard/collections/edit?id=${collection.id}`}>Edit</a>
                                    <button type="button" onClick={() => handleDeleteCollection(collection.id)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </RequireAuth>
    );
}
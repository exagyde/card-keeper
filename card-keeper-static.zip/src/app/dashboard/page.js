"use client";

import "./style.css";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { auth, firestore } from "@/firebase/config";
import { collection, getDocs, query, where, deleteDoc, doc } from "firebase/firestore";
import { AddIcon, OrderByIcon } from "@/components/Icons";
import RequireAuth from "@/components/RequireAuth";

export default function DashboardPage() {
    const router = useRouter();
    const [collections, setCollections] = useState([]);
    const [order, setOrder] = useState("asc");

    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged(async (user) => {
            if (user) {
                const userCollectionsQuery = query(
                    collection(firestore, "collections"),
                    where("userId", "==", user.uid)
                );
                const querySnapshot = await getDocs(userCollectionsQuery);
                const userCollections = querySnapshot.docs.map(doc => ({
                    id: doc.id,
                    ...doc.data()
                }));
                setCollections(userCollections);
            } else {
                router.replace("/login");
            }
        });

        return () => unsubscribe();
    }, [router]);

    const handleDeleteCollection = async (id) => {
        await deleteDoc(doc(firestore, "collections", id));
        setCollections(prevCollections => prevCollections.filter(c => c.id !== id));
    }

    const sortCollections = (field) => {
        const sortedCollections = [...collections].sort((a, b) => {
            if (a[field] == undefined && b[field] != undefined) { return 1; }
            if (a[field] != undefined && b[field] == undefined) { return -1; }
            if (a[field] < b[field]) return order === "asc" ? -1 : 1;
            if (a[field] > b[field]) return order === "asc" ? 1 : -1;
            return 0;
        });
        setOrder(order === "asc" ? "desc" : "asc");
        setCollections(sortedCollections);
    }

    return (
        <RequireAuth>
            <div id="dashboard">
                <div>
                    <h4>COLLECTIONS</h4>
                    <div>
                        {collections.length === 0 ? (
                            <p>Collections empty.</p>
                        ) : (
                            <table>
                                <thead>
                                    <tr>
                                        <th onClick={() => sortCollections("createdAt")}>Created At {OrderByIcon}</th>
                                        <th onClick={() => sortCollections("name")}>Name {OrderByIcon}</th>
                                        <th onClick={() => sortCollections("updatedAt")}>Last Update {OrderByIcon}</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {collections.map((collection) => (
                                        <tr key={collection.id}>
                                            <td>{collection.createdAt?.toDate().toLocaleDateString("fr")}</td>
                                            <td>{collection.name}</td>
                                            <td>{collection.updatedAt?.toDate().toLocaleDateString("fr") || "N/A"}</td>
                                            <td>
                                                <a href={`/dashboard/collections/edit?id=${collection.id}`}>Edit</a>
                                                <a href="#" className="red" onClick={() => handleDeleteCollection(collection.id)}>Delete</a>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        )}
                    </div>
                    <button onClick={() => router.replace("/dashboard/collections/new")}>
                        {AddIcon}
                        Create new collection
                    </button>
                </div>
            </div>
        </RequireAuth>
    );
}
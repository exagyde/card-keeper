"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { auth, firestore } from "@/firebase/config";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import RequireAuth from "@/components/RequireAuth";

export default function NewCollectionPage() {
    const router = useRouter();
    const [user, setUser] = useState(null);
    const [name, setName] = useState("");
    const [description, setDescription] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged((user) => {
            if (user) {
                setUser(user);
            } else {
                router.push("/login");
            }
        });

        return () => unsubscribe();
    }, [router]);

    const handleSubmit = async (event) => {
        event.preventDefault();
        setLoading(true);

        await addDoc(collection(firestore, "collections"), {
            name,
            description,
            userId: user.uid,
            createdAt: serverTimestamp(),
            updateAt: serverTimestamp()
        });

        router.push("/dashboard");
        setLoading(false);
    }
    
    return (
        <RequireAuth>
            <button onClick={() => router.back()}>Go back</button>
            <h1>Create a New Collection</h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor="name">Name</label>
                    <input 
                        type="text" 
                        id="name" 
                        name="name" 
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required 
                    />
                </div>
                <div>
                    <label htmlFor="description">Description</label>
                    <textarea 
                        id="description" 
                        name="description" 
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        required
                    />
                </div>
                <button type="submit" disabled={loading}>
                    {loading ? "Loading..." : "Create"}
                </button>
                {error && <p style={{ color: "red" }}>{error}</p>}
            </form>
        </RequireAuth>
    );
}
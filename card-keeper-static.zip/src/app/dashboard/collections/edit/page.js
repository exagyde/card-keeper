import { Suspense } from "react";
import RequireAuth from "@/components/RequireAuth";
import EditCollectionContent from "./content";

export default function EditCollectionPage() {
    return (
        <RequireAuth redirectTo="/dashboard">
            <Suspense fallback={<p>Loading...</p>}>
                <EditCollectionContent />
            </Suspense>
        </RequireAuth>
    );
}
"use client";

import "./style.css";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createUserWithEmailAndPassword, signInWithPopup, GoogleAuthProvider } from "firebase/auth";
import { auth } from "@/firebase/config";

const provider = new GoogleAuthProvider();

export default function SignupPage() {
    const router = useRouter();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const [checkAuth, setCheckAuth] = useState(true);

    useEffect(() => {
            const unsubscribe = auth.onAuthStateChanged((user) => {
                if (user) { router.replace("/dashboard"); } 
                else { setCheckAuth(false); }
            });
    
            return () => unsubscribe();
        }, [router]);
        if(checkAuth) return <p>Loading...</p>;

    const handleSignup = async (e) => {
        e.preventDefault();
        setError("");

        try {
            await createUserWithEmailAndPassword(auth, email, password);
            router.replace("/dashboard");
        } catch (err) {
            setError(err.message);
        }
    };

    const handleGoogleSignup = async () => {
        setError("");
        try {
            await signInWithPopup(auth, provider);
            router.replace("/dashboard");
        } catch (err) {
            setError(err.message);
        }
    };

    return (
        <div id="signup">
            <form onSubmit={handleSignup}>
                <h3>Create Your Account</h3>
                <button className="google" onClick={handleGoogleSignup}>Continue with Google</button>
                <div>
                    <hr />
                    <p>Or</p>
                    <hr />
                </div>
                <div>
                    <label htmlFor="email">Email</label>
                    <input
                        id="email"
                        type="email"
                        placeholder="Enter your email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label htmlFor="password">Password</label>
                    <input
                        id="password"
                        type="password"
                        placeholder="Enter your password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </div>
                <button type="submit">Sign Up</button>
                <small>By creating an account, you agree to the Terms of Service and Privacy Policy.</small>
                {error && <p style={{ color: "red" }}>{error}</p>}
            </form>

            <p>Already have an account?</p>
            <a href="/login">Sign In</a>
        </div>
    );
}
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
    apiKey: "AIzaSyCJwlj8thKBVWhw-cC7ZNuYoNp0RjhM4nM",
    authDomain: "cardkeeper-33bcb.firebaseapp.com",
    projectId: "cardkeeper-33bcb",
    storageBucket: "cardkeeper-33bcb.firebasestorage.app",
    messagingSenderId: "762565945628",
    appId: "1:762565945628:web:c9cdfffea449a4678532d9"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const firestore = getFirestore(app);
"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { auth } from "@/firebase/config";

export default function HomePage() {
    const router = useRouter();

    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged((user) => {
            if (user) {
                router.replace("/dashboard");
            } else {
                router.replace("/login");
            }
        });

        return () => unsubscribe();
    }, [router]);

    return <p>Loading...</p>;
}
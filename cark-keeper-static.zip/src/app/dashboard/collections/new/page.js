"use client";

import "./style.css";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { auth, firestore } from "@/firebase/config";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { AddIcon, MoveLeftIcon } from "@/components/Icons";
import RequireAuth from "@/components/RequireAuth";

export default function NewCollectionPage() {
    const router = useRouter();
    const [user, setUser] = useState(null);
    const [name, setName] = useState("");
    const [description, setDescription] = useState("");
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const unsubscribe = auth.onAuthStateChanged((user) => {
            if (user) {
                setUser(user);
            } else {
                router.replace("/login");
            }
        });

        return () => unsubscribe();
    }, [router]);

    const handleSubmit = async (event) => {
        event.preventDefault();
        setLoading(true);

        await addDoc(collection(firestore, "collections"), {
            name,
            description,
            userId: user.uid,
            createdAt: serverTimestamp()
        });

        router.replace("/dashboard");
        setLoading(false);
    }
    
    return (
        <RequireAuth>
            <div id="create-collection">
                <div>
                    <a href="/dashboard">{MoveLeftIcon} GO TO DASHBOARD</a>
                    <h4>CREATE A NEW COLLECTION</h4>
                    <form onSubmit={handleSubmit}>
                        <div>
                            <label htmlFor="name">Name</label>
                            <input 
                                type="text" 
                                placeholder="Collection Name"
                                id="name" 
                                name="name" 
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                required 
                            />
                        </div>
                        <div>
                            <label htmlFor="description">Description</label>
                            <textarea 
                                placeholder="Collection Description"
                                id="description" 
                                name="description" 
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                rows={3}
                                required
                            />
                        </div>
                        <button type="submit" disabled={loading}>
                            {loading ? "Loading..." : "Create"}
                        </button>
                    </form>
                </div>
                <small>You need to create and save the collection before you can manage it or add cards.</small>
            </div>
        </RequireAuth>
    );
}
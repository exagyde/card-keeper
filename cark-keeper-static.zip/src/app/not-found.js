export default function NotFoundPage() {
    return (
        <div>
            <p>404 not found</p>
        </div>
    );
}